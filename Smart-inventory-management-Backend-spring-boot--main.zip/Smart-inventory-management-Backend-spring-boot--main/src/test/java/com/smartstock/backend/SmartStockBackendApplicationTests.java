package com.smartstock.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartStockBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
